package es.uca.iw.proYectFlow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProYectFlowApplicationTests {

	@Test
	void contextLoads() {
	}

}
