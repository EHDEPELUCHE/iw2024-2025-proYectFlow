package es.uca.iw.data;

public enum Roles {SOLICITANTE, PROMOTOR, CIO, OTP, ADMIN};
