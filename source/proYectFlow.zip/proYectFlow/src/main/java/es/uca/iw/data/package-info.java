@NonNullApi
package es.uca.iw.data;

import org.springframework.lang.NonNullApi;
