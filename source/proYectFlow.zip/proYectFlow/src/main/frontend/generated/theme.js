import {applyTheme as _applyTheme} from './theme-proyectflow.generated.js';
export const applyTheme = _applyTheme;
